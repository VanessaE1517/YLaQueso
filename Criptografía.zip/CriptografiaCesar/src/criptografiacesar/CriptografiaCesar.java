/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package criptografiacesar;

import Encrypt.Encrypts;
import GUI.Gui;

/**
 *
 * @author vanes
 */
public class CriptografiaCesar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Gui gui= new Gui();
        gui.setVisible(true);
        
        char[] dictionary  = {'a','b','c','d','e','f','g','h','i'};
        Encrypts e = new Encrypts();
        System.out.println(e.encrypt("cafe",dictionary,6 ));
    }
    
}
