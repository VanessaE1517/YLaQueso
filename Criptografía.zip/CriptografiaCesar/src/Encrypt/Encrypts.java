/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encrypt;

/**
 *
 * @author vanes
 */
public class Encrypts {

    public Encrypts() {
       
    }
    
    public char[] encrypt(String message, char[] dictionary, int key){
        char[] nuevo = new char[message.length()];
        char[] newDictionary = new char[dictionary.length];
        for (int i = 0; i < message.length(); i++) {
            nuevo[i] = message.charAt(i);
        }
        int c =0;
        for (int i = 0; i < dictionary.length; i++) {
            if((i+key)<=8){
                newDictionary[i+key] = dictionary[i]; 
              
            }else{
               
                newDictionary[c] = dictionary[i];
                c++;
          } 
        }
        int v =0;
    
        while(v<nuevo.length){
            for (int i=0; i < dictionary.length; i++) {
                
                if(newDictionary[i] == nuevo[v]){
                   System.out.println(dictionary[i]);
                   nuevo[v]= dictionary[i];
                   v++;
                   if(v==nuevo.length)
                       break;
                 }
            }
        }
        
        
        return nuevo;
    }
    
    
}
