/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decrypt;

/**
 *
 * @author vanes
 */
    import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Decrypts  {
    private String line;
    
    public String leerArchivos() throws  IOException{
        BufferedReader buffered= new BufferedReader(new FileReader("prueba.txt"));
        this.line= buffered.readLine();
//        System.out.println(line);
        buffered.close();
        return this.line ; 
    }
    
    public void decrypt() throws IOException{ 
        leerArchivos();
        char[] c= line.toCharArray();
        
        for (int i = 0; i < c.length; i++) {
          System.out.println(c[i]);
        } 
        
        
    }
}
